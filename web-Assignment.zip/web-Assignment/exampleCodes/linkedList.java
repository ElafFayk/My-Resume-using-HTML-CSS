
package com.mycompany.employee;

public class linkedList extends createRecord{
    createRecord head;
    public int deleteRecord(int id){
         // Store head node
        createRecord temp = head, prev = null;
 
        // If head node itself holds the key to be deleted
        if (temp != null && temp.employeeID == id) {
            head = temp.next; // Changed head
            return 0;
        }
 
        // Search for the key to be deleted, keep track of
        // the previous node as we need to change temp.next
        while (temp != null && temp.employeeID != id) {
            prev = temp;
            temp = temp.next;
        }
 
        // If key was not present in linked list
        if (temp == null){
            return -1;}
 
        // Unlink the node from linked list
        //prev.next = temp.next;
        return 0;
    }
    
    public void insertRecord(createRecord new_record)
    {
        
        createRecord current;
        if (!checkRecordIsValid(new_record.employeeID)) {
            
        if (head == null || head.employeeID 
>= new_record.employeeID) {
            //set the new record to be the head
            new_record.next = head;
            head = new_record;
        }
        else {

            current = head;
  
            //do not insert the record if it is already exist
            //&&current.employeeID !=new_record.employeeID
            while (current.next != null 
      && current.next.employeeID < new_record.employeeID) {
                
              current = current.next;
            }
                  
            new_record.next = current.next;
            current.next = new_record;
        }
        }
        else {
            System.out.println("<<<Record already exists>>>" );
        }
    }
    
    private boolean checkRecordIsValid(int id) {
        createRecord current = head;
        while (current != null) {
            if (current.employeeID == id) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
    
    public void showDetails()
    {
        createRecord temp = head;
         int i=1;
        while (temp != null) {
           
            System.out.println("Employee "+i+" info : \nemployee name:"+
                    temp.employeeName +
                    "\nemployee ID:"+temp.employeeID+"\nemployee First day:"+temp.employeeFDay+ "\nemployee phone number:"+temp.employeePhoneNum+"\nemployee hour works:"
                            +temp.employeeWHours+"\nemployee salary:"+temp.employeeSalary+"\nemployee Address:"+temp.employeeAddress+"\n--------------------------" );
            ++i;
            temp = temp.next;
            
        }
    
    }
    
    public int searchRecord(int RecIDSearch){
        
    if(head==null){
        return -1;
    }
       int i=0;
       createRecord temp=head;
       while(temp !=null){
           
           if(temp.employeeID==RecIDSearch){
               
               return i;
           }
           i++;
           temp=temp.next;
       }
       return -1;
        
    }

    
     public void updateSalary(double currentSalary,int currentHours)
     {
        createRecord current = head;
        int requiredHours = 32;
        int extraHours = currentHours - requiredHours;
        double extraSalary = 0;
        while (current != null) {
        if (extraHours > 0) {
            extraSalary = currentSalary * extraHours * 0.02;
            current.employeeSalary = currentSalary+extraSalary;
            break;
            
        }
        current = current.next;
    } 
         
         
     }
     
  
     
     public void updateEmployeeName(String newName,int EmployeeID)
     {
        createRecord current = head;
        while(current != null) {
        if (current.employeeID == EmployeeID) { 
            current.employeeName = newName;
            break;
            
        }
        current = current.next;
    } 

     }
     
      public void updateEmployeePhone(int newPhone,int EmployeeID)
     {
        createRecord current = head;
        while(current != null) {
        if (current.employeeID == EmployeeID) { 
            current.employeePhoneNum = newPhone;
            break;
            
        }
        current = current.next;
    } 
         
         
     }
      public void updateEmployeeAdderss(String newAddress,int EmployeeID)
     {
        createRecord current = head;
        while(current != null) {
        if (current.employeeID == EmployeeID) { 
            current.employeeAddress = newAddress;
            break;
            
        }
        current = current.next;
    } 
         
         
     }
    public void updateEmployeeWorkHours(int newWH,int EmployeeID)
     {
        createRecord current = head;
        while(current != null) {
        if (current.employeeID == EmployeeID) { 
            current.employeeWHours = newWH;
            break;
            
        }
        current = current.next;
    } 
         
         
     }  
    
}
