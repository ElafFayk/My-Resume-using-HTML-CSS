
package com.mycompany.employee;

public class createRecord {
    public createRecord next;
    public createRecord head;
    public  String employeeName;
    public  int employeeID;
    public  String employeeFDay;
    public  int employeePhoneNum;
    public  String employeeAddress;
    public int employeeWHours;
   public  double employeeSalary;
   int i=1;

   
   public createRecord (){
         employeeName=null;
         employeeID=0;
         employeeFDay=null;
         employeePhoneNum=0;
         employeeAddress=null;
         employeeWHours=0;
         employeeSalary=0.0;
         next=null;
     }
   
     public createRecord (String n ,int id,
             String f,int p,String addr,int work,double s){
         employeeName=n;
         employeeID=id;
         employeeFDay=f;
         employeePhoneNum=p;
         employeeAddress=addr;
         employeeWHours=work;
         employeeSalary=s;
         next=null;
     }
     
   
     
}
