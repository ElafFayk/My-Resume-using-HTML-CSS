
package com.mycompany.employee;
import java.util.Scanner;
public class Employee {

    public static void main(String[] args) {
        
    Scanner inputInt=new Scanner (System.in);
    Scanner inputDouble=new Scanner (System.in);
    Scanner inputString=new Scanner (System.in);
    Scanner inputS=new Scanner (System.in);
    
    String enter,enter2,newName,newAddress;
    linkedList newe=new linkedList();
    int choice,newWorkH,choice2,workHours,ID,phoneNum,employeeID,newPhone,CHours;
     String name,address,FdayOfWork;
     double CSalary,salary;
     
     System.out.println("\t\t\t"+"**** W E L L C O M E ****"+"\n\n"+"\t\t"
                +"**** TO EMPLOYEE RECORD MANAGMENT SYSTEM ****"+"\n\n");
     System.out.println("\t\t>>> Do You Want To Start ? (If So, Enter Yes) <<< ");
     System.out.print("\t\t >> ");
     enter=inputString.nextLine();
     System.out.println();
        
         
        while(enter.equalsIgnoreCase("yes")){
            list1();
            choice=inputInt.nextInt();
            while(choice>6||choice<1){
            System.out.print("\t"+" >> Sorry it's wrong number ! \n\t >> Please try again : ");
            choice=inputInt.nextInt();    
            }
            if(choice==1){
                System.out.println("\n\t\t\t"+"******* Insert Employee Record *******\n");
                System.out.print("Please Enter Employee Name: ");
                name=inputString.nextLine();
                System.out.print("Please Enter Employee ID: ");
                ID=inputInt.nextInt();
                System.out.print("Please Enter First day of work: ");
                FdayOfWork=inputString.nextLine();
                System.out.print("Please Enter phone number: ");
                phoneNum=inputInt.nextInt();
                System.out.print("Please Enter Address: ");
                address=inputString.nextLine();
                System.out.print("Please Enter Work Hours: ");
                workHours=inputInt.nextInt();
                System.out.print("Please Enter Salary: ");
                salary=inputInt.nextInt();
                createRecord employee4=new createRecord(name,ID,FdayOfWork,phoneNum,
                address, workHours,salary);
                newe.insertRecord(employee4);
            
            }
            else if(choice==2){
                System.out.println("\n\t\t\t"+"******* Delete Employee Record *******\n");
                System.out.println("\t\t >>> Enter The Employee ID: <<< ");
                System.out.print("\t\t >> "); 
                ID=inputInt.nextInt();
                System.out.println(newe.deleteRecord(ID));
                System.out.println(".........................................................................");
                System.out.println();
            }
            else if(choice==3){
                
                System.out.println("\n\t\t\t"+"******* Update Employee Record *******\n");
                System.out.println("\t\t >>> Enter Yes To Start <<< ");
                System.out.print("\t\t >> ");
                enter2=inputString.nextLine();
                System.out.println();
                while(enter2.equalsIgnoreCase("yes")){
                list2();
                choice2=inputInt.nextInt();
                   while(choice2>4||choice2<1){
                System.out.print("\t"+" >> Sorry it's wrong number ! \n\t >> Please try again : ");
                choice2=inputInt.nextInt(); 
            
            }
              if(choice2==1){
               System.out.println("\t\t >>> Enter The New Name: <<< ");
               System.out.print("\t\t >> "); 
               newName=inputString.nextLine();
               System.out.println("\t\t >>> Enter The Employee ID: <<< ");
               System.out.print("\t\t >> "); 
                employeeID=inputInt.nextInt();
               newe.updateEmployeeName(newName,employeeID);
             
              }
              else if(choice2==2){
               System.out.println("\t\t >>> Enter The New Phone number: <<< ");
               System.out.print("\t\t >> "); 
               newPhone=inputInt.nextInt();
               System.out.println("\t\t >>> Enter The Employee ID: <<< ");
               System.out.print("\t\t >> "); 
               employeeID=inputInt.nextInt();
               newe.updateEmployeePhone(newPhone, employeeID);
              }
              else if(choice2==3){
               System.out.println("\t\t >>> Enter The New Address: <<< ");
               System.out.print("\t\t >> "); 
               newAddress=inputString.nextLine();
               System.out.println("\t\t >>> Enter The Employee ID: <<< ");
               System.out.print("\t\t >> "); 
               employeeID=inputInt.nextInt();
               newe.updateEmployeeAdderss(newAddress, employeeID);
              }
              else if(choice2==4){
               System.out.println("\t\t >>> Enter The New Work Hours: <<< ");
               System.out.print("\t\t >> "); 
               newWorkH=inputInt.nextInt();
               System.out.println("\t\t >>> Enter The Employee ID: <<< ");
               System.out.print("\t\t >> "); 
               employeeID=inputInt.nextInt();
               newe.updateEmployeeWorkHours(newWorkH, employeeID);
              }
              
            System.out.println("\t >> Do You Want To Start Again ? (If So, Enter Yes): ");
            System.out.print("\t >> ");
            enter2=inputString.nextLine();
             }
            }
            else if(choice==4){
                System.out.println("\n\t\t\t******* Show Employee Record *******\n");
                newe.showDetails();
                System.out.println(".........................................................................");
                System.out.println();
                
               
            }
            
            
            else if(choice==5){
                System.out.println("\n\t\t\t******* Search Employee Record  *******\n");
                System.out.println("\t\t >>> Enter The Employee ID: <<< ");
                System.out.print("\t\t >> "); 
                employeeID=inputInt.nextInt();
                if(newe.searchRecord(employeeID)==-1){
                    System.out.println(">>Record was not found");
                }
                else {
                    System.out.println(">>Record was found at index: "+newe.searchRecord(employeeID));
                }
                System.out.println(".........................................................................");
                System.out.println();
            }
            else if(choice==6){
                System.out.println("\n\t\t\t******* Update Employee Salary Record *******\n");
                System.out.println("\t\t >>> Enter Your Current Salary: <<< ");
                System.out.print("\t\t >> "); 
                CSalary=inputInt.nextInt();
                System.out.println("\t\t >>> Enter Your Current Working Hours: <<< ");
                System.out.print("\t\t >> "); 
                CHours=inputInt.nextInt();
                newe.updateSalary(CSalary, CHours);
                System.out.println(".........................................................................");
                System.out.println();
            }
            
            System.out.println("\t >> Do You Want To Start Again ? (If So, Enter Yes): ");
            System.out.print("\t >> ");
            enter=inputString.nextLine();
        }
        
  /*      System.out.println("\n\n\t\t>>> THANK YOU FOR USING EMPLOYEE RECORD MANAGMENT SYSTEM <<<"
                + "\n\t\t\t* See You Later *");*/
    
      
    }
     public static void list1(){
        System.out.println("\t"+"* Please, Choose What You Want From The List Below *");
        System.out.println("\t\t"+"    ____________________________________");
	System.out.println("\t\t"+"   |    EMPLOYEE RECORDS SYSTEM OPTIONS  |");
	System.out.println("\t\t"+"   |_____________________________________|");
	System.out.println("\t\t"+"   | 1. Insert Employee Record           |");//
	System.out.println("\t\t"+"   |_____________________________________|");
	System.out.println("\t\t"+"   | 2. Delete Employee Record           |");//+
        System.out.println("\t\t"+"   |_____________________________________|");    
        System.out.println("\t\t"+"   | 3. Update Employee Record           |");//+
        System.out.println("\t\t"+"   |_____________________________________|");  
	System.out.println("\t\t"+"   | 4. Show Employee Record             |");//+
	System.out.println("\t\t"+"   |_____________________________________|");
        System.out.println("\t\t"+"   | 5. Search Employee Record           |");//+
	System.out.println("\t\t"+"   |_____________________________________|");
        System.out.println("\t\t"+"   | 6. Update Employee Salary Record    |");//+
	System.out.println("\t\t"+"   |_____________________________________|");
        System.out.println("");
        System.out.print("\t"+" >> Please, Enter Your choice here : "); 
    }
     
     public static void list2(){
        System.out.println("\t"+"* Please, Choose What You Want From The List Below *");
        System.out.println("\t\t"+"    ______________________________________");
	System.out.println("\t\t"+"   |   Update EMPLOYEE RECORDS OPTIONS   |");
	System.out.println("\t\t"+"   |_____________________________________|");
	System.out.println("\t\t"+"   | 1. Update Employee Name             |");
        System.out.println("\t\t"+"   |_____________________________________|");    
        System.out.println("\t\t"+"   | 2. Update Employee phone number     |");
        System.out.println("\t\t"+"   |_____________________________________|");  
	System.out.println("\t\t"+"   | 3. Update Employee Address          |");
	System.out.println("\t\t"+"   |_____________________________________|");
        System.out.println("\t\t"+"   | 4. Update Employe Work Hours        |");
	System.out.println("\t\t"+"   |_____________________________________|");
        System.out.println("");
        System.out.print("\t"+" >> Please, Enter Your choice here : "); 
    }
}
